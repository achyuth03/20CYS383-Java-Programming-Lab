package ex;
import java.util.Scanner;

// Define the Calculator interface
interface Calculator {
    double add(double num1, double num2);
    double subtract(double num1, double num2);
    double multiply(double num1, double num2);
    double divide(double num1, double num2) throws ArithmeticException;
}

// Implement the Calculator interface in BasicCalculator
class BasicCalculator implements Calculator {
    @Override
    public double add(double num1, double num2) {
        return num1 + num2;
    }

    @Override
    public double subtract(double num1, double num2) {
        return num1 - num2;
    }

    @Override
    public double multiply(double num1, double num2) {
        return num1 * num2;
    }

    @Override
    public double divide(double num1, double num2) throws ArithmeticException {
        if (num2 == 0) {
            throw new ArithmeticException("Cannot divide by zero.");
        }
        return num1 / num2;
    }
}


public class BasicCalculatorExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BasicCalculator calculator = new BasicCalculator();

        //System.out.print("Enter the first number: ");
        double number1 = scanner.nextDouble();

        //System.out.print("Enter the second number: ");
        double number2 = scanner.nextDouble();

        double additionResult = calculator.add(number1, number2);
        System.out.println("Addition: " + additionResult);

        double subtractionResult = calculator.subtract(number1, number2);
        System.out.println("Subtraction: " + subtractionResult);

        double multiplicationResult = calculator.multiply(number1, number2);
        System.out.println("Multiplication: " + multiplicationResult);

        try {
            double divisionResult = calculator.divide(number1, number2);
            System.out.println("Division: " + divisionResult);
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        }

        scanner.close();
    }
}

