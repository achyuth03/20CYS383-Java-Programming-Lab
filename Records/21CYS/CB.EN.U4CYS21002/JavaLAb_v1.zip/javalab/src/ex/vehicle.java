package ex;
import java.util.Scanner;

class Vehicle {
    protected boolean runStatus;

    public void start() {
        runStatus = true;
        System.out.println("Vehicle started.");
    }

    public void stop() {
        runStatus = false;
        System.out.println("Vehicle stopped.");
    }
}

class Car extends Vehicle {
    private String modelName;
    private int year;
    private int numOfWheels;

    public Car(String modelName, int year, int numOfWheels) {
        this.modelName = modelName;
        this.year = year;
        this.numOfWheels = numOfWheels;
    }

    public void drive(int gearPosition) {
        if (runStatus) {
            System.out.println("Car is driving in gear position: " + gearPosition);
        } else {
            System.out.println("Error: Vehicle is not running.");
        }
    }
}

class Bike extends Vehicle {
    private String brandName;
    private int year;
    private int numOfGears;

    public Bike(String brandName, int year, int numOfGears) {
        this.brandName = brandName;
        this.year = year;
        this.numOfGears = numOfGears;
    }

    public void pedal(int pedalSpeed) {
        if (runStatus) {
            System.out.println("Bike is pedaling at speed: " + pedalSpeed);
        } else {
            System.out.println("Error: Vehicle is not running.");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter car model name: ");
        String carModel = scanner.nextLine();
        System.out.print("Enter car year: ");
        int carYear = scanner.nextInt();
        System.out.print("Enter car number of wheels: ");
        int carWheels = scanner.nextInt();

        Car car = new Car(carModel, carYear, carWheels);

        System.out.print("Enter bike brand name: ");
        scanner.nextLine(); // Consume the remaining newline character
        String bikeBrand = scanner.nextLine();
        System.out.print("Enter bike year: ");
        int bikeYear = scanner.nextInt();
        System.out.print("Enter bike number of gears: ");
        int bikeGears = scanner.nextInt();

        Bike bike = new Bike(bikeBrand, bikeYear, bikeGears);

        car.start();
        System.out.print("Enter car gear position: ");
        int carGear = scanner.nextInt();
        car.drive(carGear);
        car.stop();

        bike.start();
        System.out.print("Enter bike pedal speed: ");
        int bikeSpeed = scanner.nextInt();
        bike.pedal(bikeSpeed);
        bike.stop();

        scanner.close();
    }
}



