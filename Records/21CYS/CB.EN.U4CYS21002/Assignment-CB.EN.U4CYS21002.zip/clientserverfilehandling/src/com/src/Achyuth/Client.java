package com.src.Achyuth;

import java.io.*;
import java.net.Socket;

public class Client {
    public static void main(String[] args) throws IOException {
        Socket socket = null;
        FileInputStream fileInStream = null;
        OutputStream outStream = null;

        try {
            // Create socket to connect to the server
            socket = new Socket("localhost", 8888);

            // Get file input stream for the file to be sent
            File file = new File("/home/achyuth/Desktop/cat.txt");
            fileInStream = new FileInputStream(file);

            // Get output stream to send file data to the server
            outStream = socket.getOutputStream();

            byte[] buffer = new byte[4096];
            int bytesRead;

            // Read file data and send it to the server
            while ((bytesRead = fileInStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, bytesRead);
            }

            System.out.println("File sent successfully.");
        } finally {
            // Close all resources
            if (fileInStream != null) {
                fileInStream.close();
            }
            if (outStream != null) {
                outStream.close();
            }
            if (socket != null) {
                socket.close();
            }
        }
    }
}
