package com.src.Achyuth;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = null;
        Socket socket = null;
        InputStream inStream = null;
        FileOutputStream fileOutStream = null;

        try {
            // Create server socket
            serverSocket = new ServerSocket(8888);

            System.out.println("com.src.Achyuth.Server started. Waiting for a client to connect...");

            // Accept client connection
            socket = serverSocket.accept();
            System.out.println("Client connected.");

            // Get input stream from client
            inStream = socket.getInputStream();

            // Create file output stream to save the received file
            fileOutStream = new FileOutputStream("received_file.txt");

            byte[] buffer = new byte[4096];
            int bytesRead;

            // Read file data from client and write it to the file
            while ((bytesRead = inStream.read(buffer)) != -1) {
                fileOutStream.write(buffer, 0, bytesRead);
            }

            System.out.println("File received and saved successfully.");
        } finally {
            // Close all resources
            if (fileOutStream != null) {
                fileOutStream.close();
            }
            if (inStream != null) {
                inStream.close();
            }
            if (socket != null) {
                socket.close();
            }
            if (serverSocket != null) {
                serverSocket.close();
            }
        }
    }
}
